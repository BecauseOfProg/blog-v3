from db.models import Articles, User
from flask import render_template
from pony.orm import db_session
from app import application
import requests
import markdown


@application.route("/article/<url>")
@db_session
def article(url):
    '''Displays an article'''
    a = Articles.get(url=url)
    u = User.get(username=a.author)

    r = requests.get('https://api.becauseofprog.fr/v1/posts/last')
    devblog = r.json()

    if a.article_language == "markdown":
        htmlarticle = markdown.markdown(a.content)
    return render_template('article.html', **locals())
