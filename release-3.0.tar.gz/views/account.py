from flask import render_template, request, session, redirect
from utils.valid_login import valid_login
from pony.orm import db_session
from db.models import User
from app import application


@application.route('/login', methods=['GET', 'POST'])
@db_session
def show_login():
    if 'token' in session:
        return redirect('/')
    if request.method == 'POST':
        if valid_login(request.form['username'], request.form['password']):
            u = User.get(email=request.form['username'])
            session['email'] = u.email
            session['token'] = u.token
            session['username'] = u.username
            return redirect('/')
        else:
            return render_template('members/login.html',
                                   error="Les identifiants sont invalides")
    else:
        return render_template('members/login.html')


@application.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('token', None)
    return redirect('/')
