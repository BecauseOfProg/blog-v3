from pony.orm import Database
db = Database()
db.bind(provider='mysql', host='becauseofprog.fr', user='bop-beta', passwd='hf7fVUE5NMqgwBKz', db='bop-beta')